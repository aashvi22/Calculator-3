package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{

    TextView t;
    String s = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*Button one = findViewById(R.id.button1);
        one.setOnClickListener(this);

        Button two = findViewById(R.id.button2);
        two.setOnClickListener(this);

        Button three = findViewById(R.id.button2);
        three.setOnClickListener(this);

         */

        t  = findViewById(R.id.textView);




    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button0:
                s += "0";
                t.setText(s);
                break;
            case R.id.button1:
                s += "1";
                t.setText(s);
                break;
            case R.id.button2:
                s += "2";
                t.setText(s);
                break;
            case R.id.button3:
                s += "3";
                t.setText(s);
                break;
            case R.id.button4:
                s += "4";
                t.setText(s);
                break;
            case R.id.button5:
                s += "5";
                t.setText(s);
                break;
            case R.id.button6:
                s += "6";
                t.setText(s);
                break;
            case R.id.button7:
                s += "7";
                t.setText(s);
                break;
            case R.id.button9:
                s += "9";
                t.setText(s);
                break;
             case R.id.buttonEq:
                s += "=";
                t.setText(s);
                break;
            case R.id.buttonPlus:
                s += "+";
                t.setText(s);
                break;
            case R.id.buttonMinus:
                s += "-";
                t.setText(s);
                break;
            case R.id.buttonMult:
                s += "*";
                t.setText(s);
                break;
            case R.id.buttonDiv:
                s += "/";
                t.setText(s);
                break;
            case R.id.buttonC:
                s = "";
                t.setText(s);
                break;
        }
    }

}